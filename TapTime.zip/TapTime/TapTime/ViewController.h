//
//  ViewController.h
//  TapTime
//
//  Created by Balraj Randhawa on 25/09/14.
//  Copyright (c) 2014 Balraj Randhawa. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property(weak, nonatomic) IBOutlet UILabel *lblTime;



@end
